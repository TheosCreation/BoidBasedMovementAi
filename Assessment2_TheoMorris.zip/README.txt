# Ai-mini-project-2 Theo Morris

To spawn in a agent into the scene click anywhere on the window and it will spawn a agent.

To select a specific agent to spawn look over to the window Selector window and click a button with the agent you want to spawn and click on the game window to spawn the newly selected agent.

The first agent spawned into the scene will be the leader of the group or the leader of the queue and has the wander behaviour as a default

Implemented Behaviours:
Seek and Flee,
Pursuit and Evade,
Wander,
Arrival,
Obstacle Aviodance,
Queueing,
Leader Following,
Wall Following

Using the Seek agent as the first agent in the scene allows the user to control the agents such as leader followers and queueing agents
